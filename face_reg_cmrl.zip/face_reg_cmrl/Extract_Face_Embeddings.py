import os
import numpy as np
import cv2
from keras_facenet import FaceNet
from mtcnn import MTCNN

# Initialize FaceNet and MTCNN detector
embedder = FaceNet()
detector = MTCNN()

# Define train and test paths
train_folder = "dataset_split/train"
test_folder = "dataset_split/test"

# Function to extract embeddings
def extract_embeddings(folder):
    embeddings = []
    labels = []

    for person_name in os.listdir(folder):
        person_path = os.path.join(folder, person_name)
        if os.path.isdir(person_path):
            for image_name in os.listdir(person_path):
                image_path = os.path.join(person_path, image_name)

                # Load and preprocess image
                image = cv2.imread(image_path)
                image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                faces = detector.detect_faces(image_rgb)

                if faces:
                    x, y, w, h = faces[0]['box']
                    face = image[y:y+h, x:x+w]
                    face = cv2.resize(face, (160, 160))
                    face = np.expand_dims(face, axis=0)

                    # Extract embedding
                    face_embedding = embedder.embeddings(face)
                    embeddings.append(face_embedding.flatten())
                    labels.append(person_name)

    return np.array(embeddings), np.array(labels)

# Extract and save train embeddings
X_train, y_train = extract_embeddings(train_folder)
np.save("face_embeddings_train.npy", X_train)
np.save("face_labels_train.npy", y_train)

# Extract and save test embeddings
X_test, y_test = extract_embeddings(test_folder)
np.save("face_embeddings_test.npy", X_test)
np.save("face_labels_test.npy", y_test)

print("✅ Embeddings extracted and saved successfully!")
