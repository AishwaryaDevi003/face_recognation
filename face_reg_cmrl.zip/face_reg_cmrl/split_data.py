import os
import shutil
import random

# Input (augmented) and output (train/test) folders
input_folder = "augmented_images"
output_folder = "dataset_split"
train_folder = os.path.join(output_folder, "train")
test_folder = os.path.join(output_folder, "test")

# Create train and test directories
os.makedirs(train_folder, exist_ok=True)
os.makedirs(test_folder, exist_ok=True)

def split_data(train_ratio=0.8):
    """Splits the dataset into train and test sets."""
    for person_name in os.listdir(input_folder):
        person_folder = os.path.join(input_folder, person_name)
        if os.path.isdir(person_folder):
            images = os.listdir(person_folder)
            random.shuffle(images)  # Shuffle images to avoid bias

            # Calculate split index
            split_index = int(len(images) * train_ratio)
            train_images = images[:split_index]
            test_images = images[split_index:]

            # Create subfolders
            train_subfolder = os.path.join(train_folder, person_name)
            test_subfolder = os.path.join(test_folder, person_name)
            os.makedirs(train_subfolder, exist_ok=True)
            os.makedirs(test_subfolder, exist_ok=True)

            # Move images to respective folders
            for img_name in train_images:
                shutil.copy(os.path.join(person_folder, img_name), os.path.join(train_subfolder, img_name))

            for img_name in test_images:
                shutil.copy(os.path.join(person_folder, img_name), os.path.join(test_subfolder, img_name))

            print(f"Split {person_name}: {len(train_images)} train, {len(test_images)} test")

# Run dataset split
split_data()