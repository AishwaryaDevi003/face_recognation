import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load your test data
X_test = np.load("face_embeddings_test.npy")
y_test = np.load("face_labels_test.npy")

# 2. Load the saved model and label encoder classes
model = load_model("face_recognition_model.h5")
label_encoder_classes = np.load("label_encoder_classes.npy", allow_pickle=True)

# 3. Encode your test labels to match training format
from sklearn.preprocessing import LabelEncoder
label_encoder = LabelEncoder()
label_encoder.classes_ = label_encoder_classes
y_test_encoded = label_encoder.transform(y_test)

# Convert to one-hot encoding
y_test_onehot = tf.keras.utils.to_categorical(y_test_encoded, len(label_encoder.classes_))

# 4. Evaluate the model
test_loss, test_acc = model.evaluate(X_test, y_test_onehot)
print(f"\nTest Accuracy: {test_acc:.4f}")
print(f"Test Loss: {test_loss:.4f}")

# 5. Generate predictions
y_pred = model.predict(X_test)
y_pred_classes = np.argmax(y_pred, axis=1)

# 6. Classification report
print("\nClassification Report:")
print(classification_report(y_test_encoded, y_pred_classes, 
                          target_names=label_encoder.classes_))

# 7. Confusion matrix
conf_mat = confusion_matrix(y_test_encoded, y_pred_classes)
plt.figure(figsize=(10, 8))
sns.heatmap(conf_mat, annot=True, fmt='d',
           xticklabels=label_encoder.classes_,
           yticklabels=label_encoder.classes_)
plt.title('Confusion Matrix')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.show()