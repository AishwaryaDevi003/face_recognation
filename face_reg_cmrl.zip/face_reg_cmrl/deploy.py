import cv2
import numpy as np
from tensorflow.keras.models import load_model
from mtcnn import MTCNN
from keras_facenet import FaceNet
from sklearn.metrics.pairwise import cosine_similarity

# Initialize face detector and FaceNet embedder
detector = MTCNN()
embedder = FaceNet()

# Load the trained model and label encoder
model = load_model("face_recognition_model.h5")
label_encoder_classes = np.load("label_encoder_classes.npy", allow_pickle=True)

# Load training embeddings for similarity comparison
train_embeddings = np.load("face_embeddings_train.npy", allow_pickle=True)
train_labels = np.load("face_labels_train.npy", allow_pickle=True)  # Added training labels

# Normalize training embeddings
train_embeddings /= np.linalg.norm(train_embeddings, axis=1, keepdims=True)

# Set thresholds
SIMILARITY_THRESHOLD = 0.70  # Minimum cosine similarity to consider a match

def recognize_faces():
    cap = cv2.VideoCapture(0)
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        # Convert to RGB (MTCNN expects RGB)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Detect faces
        faces = detector.detect_faces(frame_rgb)
        
        for face in faces:
            x, y, w, h = face['box']
            
            # Adjust coordinates that might be negative
            x, y = max(0, x), max(0, y)
            
            # Extract face ROI
            face_img = frame[y:y+h, x:x+w]
            
            # Resize and preprocess for FaceNet
            face_img = cv2.resize(face_img, (160, 160))
            face_img = np.expand_dims(face_img, axis=0)
            
            try:
                # Get embedding (512-D vector)
                embedding = embedder.embeddings(face_img)
                embedding /= np.linalg.norm(embedding)  # Normalize
                
                # Calculate similarity with all training embeddings
                similarities = cosine_similarity(embedding, train_embeddings)[0]
                max_similarity = np.max(similarities)
                best_match_idx = np.argmax(similarities)
                
                # Get the actual accuracy score (similarity to closest training sample)
                accuracy_score = max_similarity
                
                # Only accept if above threshold
                if accuracy_score > SIMILARITY_THRESHOLD:
                    name = train_labels[best_match_idx]  # Use label from training data
                    color = (0, 255, 0)  # Green for known
                else:
                    name = "Unknown"
                    color = (0, 0, 255)  # Red for unknown
                
                # Draw rectangle and label with accuracy score
                cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                label = f"{name}: {accuracy_score:.2f}"  # Show actual similarity score
                cv2.putText(frame, label, (x, y-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)
                
                # Debugging output
                print(f"Best match: {name}, Similarity: {accuracy_score:.2f}")
                
            except Exception as e:
                print(f"Error processing face: {e}")
                continue
        
        # Display output
        cv2.imshow('Face Recognition', frame)
        
        # Press 'q' to quit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
            
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    print("Starting face recognition...")
    recognize_faces()