import os
import cv2
from mtcnn import MTCNN

# Input and output folders
input_folder = "captured_images"  # Change if needed
output_folder = "preprocessed_images"

# Initialize face detector
detector = MTCNN()

# Create output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

def preprocess_images():
    for person in os.listdir(input_folder):
        person_path = os.path.join(input_folder, person)

        # ✅ Skip if it's NOT a directory (to avoid .pkl or other files)
        if not os.path.isdir(person_path):
            print(f"Skipping non-folder file: {person}")
            continue  

        output_person_path = os.path.join(output_folder, person)
        os.makedirs(output_person_path, exist_ok=True)

        for img_name in os.listdir(person_path):
            img_path = os.path.join(person_path, img_name)
            image = cv2.imread(img_path)

            if image is None:
                print(f"Skipping {img_name}: Unable to read.")
                continue

            # Convert to RGB (MTCNN requires RGB images)
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            # Detect faces
            faces = detector.detect_faces(image_rgb)

            if faces:
                x, y, w, h = faces[0]['box']  # Extract first detected face
                face = image_rgb[y:y+h, x:x+w]  # Crop face
                face_resized = cv2.resize(face, (160, 160))  # Resize for FaceNet

                # Convert to grayscale
                face_gray = cv2.cvtColor(face_resized, cv2.COLOR_RGB2GRAY)

                # Save preprocessed image
                save_path = os.path.join(output_person_path, img_name)
                cv2.imwrite(save_path, face_gray)
                print(f"✅ Processed: {save_path}")
            else:
                print(f"❌ No face detected in {img_name}, skipping.")

preprocess_images()
