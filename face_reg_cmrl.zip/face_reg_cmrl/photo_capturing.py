import sys
import cv2
import os
import time
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget, QLineEdit, QMessageBox
from PyQt5.QtGui import QImage, QPixmap

class CameraCaptureApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Face Data Collection")
        self.setGeometry(100, 100, 800, 600)

        self.layout = QVBoxLayout()

        # Label for Webcam Feed
        self.label = QLabel("Webcam Feed")
        self.layout.addWidget(self.label)

        # Input field for person's name
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Enter person name")
        self.layout.addWidget(self.name_input)

        # Capture button
        self.capture_button = QPushButton("Capture 20 Images")
        self.capture_button.clicked.connect(self.capture_images)
        self.layout.addWidget(self.capture_button)

        self.image_label = QLabel()
        self.layout.addWidget(self.image_label)

        # Set layout
        container = QWidget()
        container.setLayout(self.layout)
        self.setCentralWidget(container)

        # Initialize camera
        self.cap = cv2.VideoCapture(0)
        self.timer = self.startTimer(20)  

        self.image_count = 0  # Counter for captured images
        self.image_limit = 20  # Number of images per person
        self.base_directory = "captured_images"  # Main directory for captured images

        os.makedirs(self.base_directory, exist_ok=True)

    def timerEvent(self, event):
        """ Continuously updates the webcam feed """
        ret, frame = self.cap.read()
        if ret:
            height, width, channel = frame.shape
            bytes_per_line = 3 * width
            q_img = QImage(frame.data, width, height, bytes_per_line, QImage.Format_RGB888).rgbSwapped()
            self.label.setPixmap(QPixmap.fromImage(q_img))

    def capture_images(self):
        """ Captures 20 images and saves them into a folder for each person """
        person_name = self.name_input.text().strip()
        if not person_name:
            QMessageBox.warning(self, "Input Error", "Please enter a valid person name before capturing.")
            return

        # Create a folder for this person
        person_directory = os.path.join(self.base_directory, person_name)
        os.makedirs(person_directory, exist_ok=True)

        self.image_count = 0

        while self.image_count < self.image_limit:
            ret, frame = self.cap.read()
            if ret:
                image_path = os.path.join(person_directory, f"{person_name}_{self.image_count + 1}.jpg")
                cv2.imwrite(image_path, frame)
                print(f"✅ Captured {image_path}")
                self.image_label.setText(f"Captured {self.image_count + 1} images for {person_name}")

                # Wait for 1 second to allow the person to change angle
                time.sleep(1)

                self.image_count += 1

        QMessageBox.information(self, "Capture Complete", f"Captured {self.image_limit} images for {person_name}.")

    def closeEvent(self, event):
        """ Releases camera on close """
        self.cap.release()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CameraCaptureApp()
    window.show()
    sys.exit(app.exec_())
